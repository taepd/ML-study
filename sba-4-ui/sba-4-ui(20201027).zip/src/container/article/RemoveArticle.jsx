import React from 'react'
import {Article} from '../../templates'

const RemoveArticle = () => {
    return (<Article>

    </Article>)
}

export default RemoveArticle