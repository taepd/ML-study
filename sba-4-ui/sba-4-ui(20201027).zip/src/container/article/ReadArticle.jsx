import React from 'react'
import {Article} from '../../templates'

const ReadArticle = () => {
    return (<Article>

    </Article>)
}

export default ReadArticle