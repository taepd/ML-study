import React from 'react'
import {Article} from '../../templates'

const EditArticle = () => {
    return (<Article>

    </Article>)
}

export default EditArticle