import React from 'react'
import {Article} from '../../templates'

const WriteArticle = () => {
    return (<Article>

    </Article>)
}

export default WriteArticle