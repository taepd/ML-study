import React from 'react'
import {Article} from '../../templates'

const ArticleList = () => {
    return (<Article>
        <table>
            <tr>
                <td></td>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td></td>
            </tr>
        </table>
    </Article>)
}

export default ArticleList