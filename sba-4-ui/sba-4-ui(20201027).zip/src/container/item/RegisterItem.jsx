import React from 'react'
import {Item} from '../../templates'

const RegisterItem = () => {
    return (<Item>

    </Item>)
}

export default RegisterItem