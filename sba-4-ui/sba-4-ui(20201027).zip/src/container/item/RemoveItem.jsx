import React from 'react'
import {Item} from '../../templates'

const RemoveItem = () => {
    return (<Item>

    </Item>)
}

export default RemoveItem