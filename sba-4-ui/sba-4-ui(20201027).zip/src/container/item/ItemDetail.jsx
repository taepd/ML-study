import React from 'react'
import {Item} from '../../templates'

const ItemDetail = () => {
    return (<Item>

    </Item>)
}

export default ItemDetail